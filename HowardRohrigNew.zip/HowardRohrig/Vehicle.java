//Tommy
public abstract class Vehicle {//Create abstract class
    abstract public double GetCarbonFootprint(); //Create abstract method
}
