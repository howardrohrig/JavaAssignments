//Tommy
public class VehicleTest {
    public static void main(String[] args) {
       
        Vehicle[] vehicles = new Vehicle[2];
        vehicles[0] = new Car(69);
        vehicles[1] = new Bicycle();
        
        for(Vehicle i:vehicles) {
            if(i.GetCarbonFootprint()== 0) {
                System.out.printf("The carbon footprint for your bike is: %.2f\n", i.GetCarbonFootprint());
            } else {
                System.out.printf("The carbon footprint for your car is: %.2f\n", i.GetCarbonFootprint());
            }
        }
    }
}
