
import javax.swing.JFrame;

/*
 * @author Tommy
 */
public class ConvertTest {
    
    public static void main(String[] args) {
        
        ConvertFrame myFrame = new ConvertFrame();
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setSize(550,180);
        myFrame.setVisible(true);
        
    }
}
