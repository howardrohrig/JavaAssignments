
public class Bicycle extends Vehicle {
    
    @Override
    public double GetCarbonFootprint(){
        return 0;
    }
}
