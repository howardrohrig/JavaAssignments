//Tommy
public class Car extends Vehicle {
    
    private final double gallons;
    
    public Car(double gallons){
        this.gallons = gallons;
    }
    
    @Override
    public double GetCarbonFootprint() {
        return this.gallons*20;
    }
}
