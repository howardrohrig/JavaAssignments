
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


/*
 * @author Tommy
 */
public class ConvertFrame extends JFrame {
   
    private final JLabel tempLabel;
    private final JLabel lengLabel;
    private final JLabel endTempLabel;
    private final JLabel endLengLabel;
    private final JTextField tempField;
    private final JTextField lengField;
    private final JButton tempButton;
    private final JButton lengButton;
    
    public ConvertFrame () {
        super("Converter");
        setLayout(new FlowLayout());
        
        //Creating labels
        tempLabel = new JLabel("Enter Fahrenheit temperature: ");
        lengLabel = new JLabel("Enter Inch Length: ");
        endTempLabel = new JLabel("Fahrenheit to Celsius is: ");
        endLengLabel = new JLabel("Inch to Centimeter is: ");
        
        //Creating text fields
        tempField = new JTextField(5);
        lengField = new JTextField(5);
        
        //Creating command buttons
        tempButton = new JButton("Convert");
        lengButton = new JButton("Convert");
        
        //Adding elements
        add(tempLabel);
        add(tempField);
        add(tempButton);
        add(endTempLabel);
        
        add(lengLabel);
        add(lengField);
        add(lengButton);
        add(endLengLabel);
        
        //Adding action listeners
        Handler myHandler = new Handler();
        
        tempField.addActionListener(myHandler);
        lengField.addActionListener(myHandler);
        
        tempButton.addActionListener(myHandler);
        lengButton.addActionListener(myHandler);
        
    }//End constructor
    
    private class Handler implements ActionListener {
        
        @Override
        public void actionPerformed(ActionEvent event) {
            
            if(event.getSource() == tempField || event.getSource() == tempButton) {
                int farenheit = Integer.parseInt(tempField.getText());
                int convertedTemp = (((farenheit-32))*5)/9;
                endTempLabel.setText("Fahrenheit to Celsiusis: " + convertedTemp);
            }
            else {
                int inches = Integer.parseInt(lengField.getText());
                int convertedLeng = (int) (inches*2.54);
                endLengLabel.setText("Inch to Centimeter is: " + convertedLeng);
            }
        }
        
    }//End Handler
    
}
