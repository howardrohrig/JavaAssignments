import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class AddressOptions {
    private Connection connection=null;
    private Statement statement=null;
    private PreparedStatement preparedStatement=null;
    
    public AddressOptions () {
        try {
            connection = DriverManager.getConnection(Database.getDATABASE_URL(),
                    Database.getUSERNAME(), Database.getPASSWORD());
        } catch (SQLException ex) {
            Logger.getLogger(AddressOptions.class.getName()).log(Level.SEVERE,
                    null,ex);
        }
    }//End Constructor
    
    public ArrayList <Address> viewAddress () {
        
        try {
            ArrayList <Address> address = new ArrayList <Address>();
            String query = "select * from ADDRESSES";
            statement = connection.createStatement();
            ResultSet rs=statement.executeQuery((query));
            
            while(rs.next()) {
                int id= rs.getInt("ADDRESSID");
                String firstName= rs.getString("FIRSTNAME");
                String lastName= rs.getString("LASTNAME");
                String email= rs.getString("EMAIL");
                String phoneNumber = rs.getString("PHONENUMBER");
                
                address.add(new Address(id,firstName,lastName,email,phoneNumber));
            }
            
            return address;
            
        } catch (SQLException ex) {
            Logger.getLogger(AddressOptions.class.getName()).log(Level.SEVERE, 
                    null, ex);
            return null;
        }
    }//End View Address method
    
    public void addAddress(String firstName, String lastName, String email, 
            String phoneNumber) {
        try {
            String query="insert into ADDRESSES (FIRSTNAME, LASTNAME, EMAIL, " +
                    "PHONENUMBER) values (?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, phoneNumber);
            preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(AddressOptions.class.getName()).log(Level.SEVERE, 
                    null, ex);
        }
    }//End Add Address method
    
    public void deleteAddress(int id) {
        try {
            String query="delete from ADDRESSES where ADDRESSID=?";
            preparedStatement=connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AddressOptions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//End Delete Address method
    
    public void deleteAll() {
        try {
            String query = "delete from ADDRESSES";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(AddressOptions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void updateAddress(int id, String firstName, String lastName, 
            String email, String phoneNumber) {
        try {
            String query="update ADDRESSES set FIRSTNAME=?, LASTNAME=?, EMAIL=?, "
                    + "PHONENUMBER=? where ADDRESSID=?";
            preparedStatement= connection.prepareStatement(query);
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, phoneNumber);
            preparedStatement.setInt(5, id);
            preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(AddressOptions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//End Update Address
}
