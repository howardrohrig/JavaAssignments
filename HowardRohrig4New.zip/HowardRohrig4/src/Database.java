
public class Database {
    
    private static final String DATABASE_URL=
            "jdbc:derby://localhost:1527/addressbook";
    private static final String USERNAME="uta";
    private static final String PASSWORD="12345";

    public static String getDATABASE_URL() {
        return DATABASE_URL;
    }

    public static String getUSERNAME() {
        return USERNAME;
    }

    public static String getPASSWORD() {
        return PASSWORD;
    }
    
    
}
