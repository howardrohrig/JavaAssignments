
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.awt.event.InputEvent.CTRL_DOWN_MASK;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;


public class MyMenuFrame extends JFrame {
    private final BorderLayout layout;
    private final JTextArea textArea;
    private final JMenu fileMenu;
    private final JMenu editMenu;
    private final JMenu colorSubMenu;
    private final JMenu fontSubMenu;
    private final JMenu printMenu;
    private final JMenu helpMenu;
    private final JRadioButtonMenuItem[] fontItem;
    private final JCheckBoxMenuItem[] styleItem;
    private final ButtonGroup fontButtonGroup;
    private final JMenuItem openItem;
    private final JMenuItem saveItem;
    private final JMenuItem exitItem;
    private final JMenuItem colorItem;
    private final JMenuItem printItem;
    private final JMenuItem aboutItem;
    private final JMenuItem homeItem;
    private final JMenuBar bar = new JMenuBar();
    
    public MyMenuFrame() {
        super("MyNotepad");
        layout = new BorderLayout(5,5);
        setLayout(layout);
        textArea = new JTextArea();
        add(textArea);
        //*******************************************************************//
        //FileMenu setup
        fileMenu = new JMenu("File");
        fileMenu.setMnemonic('F');
        //Adding OpenItem
        openItem = new JMenuItem("Open");
        openItem.setAccelerator(KeyStroke.getKeyStroke('O',CTRL_DOWN_MASK));
        fileMenu.add(openItem);
        openItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event){
                openFileAction(event);
            }
        });//Opens File
        //Separator
        fileMenu.addSeparator();
        //Adding SaveItem
        saveItem = new JMenuItem("Save");
        saveItem.setAccelerator(KeyStroke.getKeyStroke('O',CTRL_DOWN_MASK));
        fileMenu.add(saveItem);
        saveItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                saveFileAction(event);
            }
        });//Saves File
        //Separator
        fileMenu.addSeparator();
        //Adding ExitItem
        exitItem = new JMenuItem("Exit");
        exitItem.setAccelerator(KeyStroke.getKeyStroke('O',CTRL_DOWN_MASK));
        fileMenu.add(exitItem);
        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event){
                System.exit(0);
            }
        });//Exits Program
        //*******************************************************************//
        //EditMenu setup
        editMenu = new JMenu("Edit");
        editMenu.setMnemonic('D');
        //ColorSubMenu setup
        colorSubMenu = new JMenu("Color");
        colorSubMenu.setMnemonic('C');
        editMenu.add(colorSubMenu);
        //Adding ColorItem
        colorItem = new JMenuItem("Change Color");
        colorItem.setAccelerator(KeyStroke.getKeyStroke('C',CTRL_DOWN_MASK));
        colorSubMenu.add(colorItem);
        colorItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                Color color = JColorChooser.showDialog(bar,"Select a color", 
                Color.RED);
                textArea.setForeground(color);
            }
        });//Color Selector
        //Separator
        editMenu.addSeparator();
        //FontSubMenu setup
        fontSubMenu = new JMenu("Font");
        fontSubMenu.setMnemonic('F');
        editMenu.add(fontSubMenu);
        //Adding FontItem
        String [] fonts = {"Times New Roman", "Arial", "Serif"};
        fontButtonGroup = new ButtonGroup();
        fontItem = new JRadioButtonMenuItem[fonts.length];
        ItemHandler itemHandler = new ItemHandler();
        for(int count=0;count<fonts.length;count++) {
            fontItem[count] = new JRadioButtonMenuItem(fonts[count]);
            fontSubMenu.add(fontItem[count]);
            fontButtonGroup.add(fontItem[count]);
            fontItem[count].addActionListener(itemHandler);
        }
        //Separator
        fontSubMenu.addSeparator();
        //Adding StyleItem
        String [] styles = {"Bold","Italic"};
        styleItem = new JCheckBoxMenuItem[styles.length];
        StyleHandler styleHandler = new StyleHandler();
        for(int count=0;count<styles.length;count++){
            styleItem[count] = new JCheckBoxMenuItem(styles[count]);
            fontSubMenu.add(styleItem[count]);
            styleItem[count].addItemListener(styleHandler);
        }
        //*******************************************************************//
        //PrintMenu setup
        printMenu = new JMenu("Print");
        printMenu.setMnemonic('P');
        //Adding PrintItem
        printItem = new JMenuItem("Send to Printer");
        printItem.setAccelerator(KeyStroke.getKeyStroke('P',CTRL_DOWN_MASK));
        printMenu.add(printItem);
        printItem.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent event) {
            int selection = JOptionPane.showOptionDialog(//Selection equals 0 or 1
                MyMenuFrame.this, 
                "Do you want to print this file?", 
                "Confirmation", JOptionPane.OK_CANCEL_OPTION, 
                JOptionPane.QUESTION_MESSAGE,null, null, null);
            if(selection==0){
                JOptionPane.showMessageDialog(MyMenuFrame.this, 
                        "The file was successfully printed!","Confirmation",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        }
        });//Shows Print Dialogue
        //*******************************************************************//
        //HelpMenu setup
        helpMenu = new JMenu("Help");
        helpMenu.setMnemonic('H');
        //Adding AboutItem
        aboutItem = new JMenuItem("About");
        aboutItem.setAccelerator(KeyStroke.getKeyStroke('A',CTRL_DOWN_MASK));
        helpMenu.add(aboutItem);
        aboutItem.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent event) {
                JOptionPane.showMessageDialog(MyMenuFrame.this,
                        "This software was developed in 2019\nVersion is 1.0",
                        "About",JOptionPane.INFORMATION_MESSAGE);
            }
        });
        //Adding HomeItem
        homeItem = new JMenuItem("Visit Homepage");
        homeItem.setAccelerator(KeyStroke.getKeyStroke('V',CTRL_DOWN_MASK));
        helpMenu.add(homeItem);
        homeItem.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent event){
                openWebpage("http://www.microsoft.com");
            }
        });
        //*******************************************************************//
        //Adding Menus to Bar
        setJMenuBar(bar);
        bar.add(fileMenu);
        bar.add(editMenu);
        bar.add(printMenu);
        bar.add(helpMenu);
        
    }//End Constructor
    //***********************************************************************//
    private void openFileAction(ActionEvent evt){
        JFileChooser fc = new JFileChooser();
        int i = fc.showOpenDialog(this);
        if(i==JFileChooser.APPROVE_OPTION){
            File file=fc.getSelectedFile();
            try(Scanner scanner = new Scanner(new BufferedReader(new FileReader(file)))) {
                String content="";
                while(scanner.hasNextLine()){
                    content+=scanner.nextLine()+"\n";
                }
                
                textArea.setText(content);
            }catch(FileNotFoundException ex) {
                Logger.getLogger(MyMenuFrame.class.getName()).log(Level.SEVERE,null,ex);
            }
        }
    }//End openFileAction Method
    //***********************************************************************//
    private void saveFileAction(ActionEvent evt) {
        JFileChooser fc = new JFileChooser();
        int answer = fc.showSaveDialog(this);
        if(answer==JFileChooser.APPROVE_OPTION) {
            String path=fc.getSelectedFile().getPath();
            try(FileWriter writer = new FileWriter(path)) {
                writer.write(textArea.getText());
            }catch(IOException ex) {
                Logger.getLogger(MyMenuFrame.class.getName()).log(Level.SEVERE,null,ex);
            }
        }
    }//End saveFileAction Method
    //***********************************************************************//
    public static void openWebpage(String urlString) {
        try{
            Desktop.getDesktop().browse(new URL(urlString).toURI());
        }catch(Exception e){
            e.printStackTrace();
        }
    }//End openWebpage Method
    //***********************************************************************//
    //ItemHandler Class
    private class ItemHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            for(int count=0;count<fontItem.length;count++){
                if(event.getSource()==fontItem[count]){
                    textArea.setFont(new Font(fontItem[count].getText(),Font.PLAIN,20));
                }
            }
        }
    }//End ItemHandler Class
    //***********************************************************************//
    //StyleHandler Class
    private class StyleHandler implements ItemListener {
        @Override
        public void itemStateChanged(ItemEvent event) {
            String fontName = textArea.getFont().getName();
            Font font;
            if(styleItem[0].isSelected()&&styleItem[1].isSelected()){
                font = new Font(fontName,Font.BOLD+Font.ITALIC,20);
            }
            else if(styleItem[0].isSelected()){
                font = new Font(fontName,Font.BOLD,20);
            }
            else if(styleItem[1].isSelected()){
                font = new Font(fontName,Font.ITALIC,20);
            }else{
                font = new Font(fontName,Font.PLAIN,20);
            }
            textArea.setFont(font);
            repaint();
        }
    }//End StyleHandler Class
}//End MyMenuFrameClass
