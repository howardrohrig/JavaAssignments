
import javax.swing.JFrame;


public class MyMenuFrameTest {
    public static void main(String[] args) {
        MyMenuFrame myFrame = new MyMenuFrame();
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setSize(600,400);
        myFrame.setVisible(true);
    }
}
