
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;


public class PizzaSelectionFrame extends JFrame{
    private final FlowLayout layout;
    private final Container container;
    private final JComboBox <String> pizzaComboBox;
    private JRadioButton smallButton;
    private JRadioButton mediumButton;
    private JRadioButton largeButton;
    private ButtonGroup buttonGroup;
    private JCheckBox topMushroom;
    private JCheckBox topBacon;
    private final JButton submitButton;
    private final JLabel labelPizza;
    private final JLabel labelSize;
    private final JLabel labelToppings;
    private int selection;
    private static final String[] imageNames = {
        "chicken.PNG","pepperoni.PNG","veggie.PNG"
    };//Array for getResource location
    private static final String[] specialties = {
        "Chicken Pizza","Pepperoni Pizza","Vegetable Pizza"
    };//Array for names of pizzas
    private final Icon[] pizzaIcons = {
        new ImageIcon(getClass().getResource(imageNames[0])),
        new ImageIcon(getClass().getResource(imageNames[1])),
        new ImageIcon(getClass().getResource(imageNames[2]))
    };//Setting Pizza Icons
    
    public PizzaSelectionFrame() {
        //Setting title, layout, container and background color
        super("Order Pizza");
        layout = new FlowLayout();
        setLayout(layout);
        container = getContentPane(); 
        container.setBackground(Color.LIGHT_GRAY);
        //Setting up Combo Box
        pizzaComboBox = new JComboBox<String>(specialties);
        pizzaComboBox.setMaximumRowCount(3);
        //Setting up Radio Buttons
        smallButton = new JRadioButton("Small", true);
        mediumButton = new JRadioButton("Medium", false);
        largeButton = new JRadioButton("Large", false);
        //Setting up Check Boxes
        topMushroom = new JCheckBox("Mushroom");
        topBacon = new JCheckBox("Bacon");
        //Setting up Submit Button
        submitButton = new JButton("Submit Order");
        //Adding label and Combo Box
        labelPizza = new JLabel(pizzaIcons[0]);
        add(labelPizza);
        add(pizzaComboBox);
        //Adding "Select Size: " label
        labelSize = new JLabel("Select Size: ");
        add(labelSize);
        //Adding buttons
        add(smallButton);
        add(mediumButton);
        add(largeButton);
        //Adding buttons to Button Group
        buttonGroup = new ButtonGroup();
        buttonGroup.add(smallButton);
        buttonGroup.add(mediumButton);
        buttonGroup.add(largeButton);
        //Adding "Select Topping(s): " label
        labelToppings = new JLabel("Select Topping(s): ");
        add(labelToppings);
        //Adding check box
        add(topMushroom);
        add(topBacon);
        //Adding button
        add(submitButton);
        //Combo Box listener
        pizzaComboBox.addItemListener(
        new ItemListener(){
            @Override
            public void itemStateChanged(ItemEvent event) {
                labelPizza.setIcon(pizzaIcons[pizzaComboBox.getSelectedIndex()]);
            }//End itemStateChanged
        }//End ItemListener
        );//End Combo Box listener
        submitButton.addActionListener(
        new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                String comboBoxText = pizzaComboBox.getSelectedItem().toString().toLowerCase();
                String radioButtonText = "";
                String checkBoxText = "";
                //**Checking Radio Buttons**//
                if(smallButton.isSelected()){
                    radioButtonText=" Small size ";
                }else if(mediumButton.isSelected()){
                    radioButtonText=" Medium size ";
                }else{
                    radioButtonText=" Large size ";
                }
                //**End Checking Radio Buttons**//
                //**Checking Check Boxes**//
                if(topMushroom.isSelected() && !(topBacon.isSelected())){
                    checkBoxText=" with mushrooms.";
                }else if(topBacon.isSelected() && !(topMushroom.isSelected())){
                    checkBoxText=" with bacon.";
                }else if(topBacon.isSelected() && topMushroom.isSelected()){
                    checkBoxText=" with mushrooms and bacon.";
                }else{
                    checkBoxText=".";
                }
                //**End Checking Check Boxes**//
                selection = JOptionPane.showOptionDialog(//Selection equals 0 or 1
                PizzaSelectionFrame.this, 
                "Order Summary:"+radioButtonText+comboBoxText+checkBoxText, 
                "Confirmation", JOptionPane.OK_CANCEL_OPTION, 
                JOptionPane.QUESTION_MESSAGE,null, null, null);
                if(selection==0){//Setting up Payment Frame
                    PaymentFrame paymentWindow = new PaymentFrame();
                    paymentWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    paymentWindow.setSize(600,200);
                    paymentWindow.setVisible(true);
                    PizzaSelectionFrame.this.setVisible(false);
                }
            }
        }
        );
    }//End PizzaSelectionFrame Constructor
}//End PizzaSelectionFrame Class
