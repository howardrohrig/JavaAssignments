
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class PizzaSelectionTest {
    public static void main(String[] args) {
        PizzaSelectionFrame myFrame = new PizzaSelectionFrame();
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setSize(325,300);
        myFrame.setVisible(true);
    }
}
