
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class PaymentFrame extends JFrame{
    private final GridLayout layout;
    private final Container container;
    private final JLabel[] labels;
    private final JTextField[] textFields;
    private static final String[] labelNames={
        "Name and Surname:","Address:","Credit Card Number:",
        "Expiration Date:","CVC:"
    };
    private final JButton pay;
    
    public PaymentFrame() {
        super("Payment");
        layout = new GridLayout(6,2,5,5);
        setLayout(layout);
        container = getContentPane();
        container.setBackground(Color.LIGHT_GRAY);
        //Setting up Text Fields and Labels
        textFields = new JTextField[labelNames.length];
        labels = new JLabel[labelNames.length];
        pay = new JButton("Pay");
        for(int i=0;i<labelNames.length;i++){
            labels[i] = new JLabel(labelNames[i]);
            add(labels[i]);
            textFields[i] = new JTextField(20);
            add(textFields[i]);
        }
        add(pay);
        pay.addActionListener(
        new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent event) {
                String infoMess = "Your order will be delivered in 30 minutes.";
                JOptionPane.showMessageDialog(null,infoMess,"Message",
                        JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        }
        );
    }
}
